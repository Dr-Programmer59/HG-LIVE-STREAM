export default function Heading() {
  return <h1></h1>;
}
