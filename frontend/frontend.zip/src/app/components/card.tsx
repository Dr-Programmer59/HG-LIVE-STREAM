export default function Card() {
  return <div></div>;
}
