import React from 'react'

const ChannelPage = () => {
  return (
    <div>ChannelPage</div>
  )
}

export default ChannelPage